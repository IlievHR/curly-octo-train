/** @type {import('tailwindcss').Config} */
module.exports = {
  content: [
    "./resources/**/*.js",
    "./resources/**/*.vue",
    './src/**/*.vue',
],
  theme: {
    extend: {},
  },
  plugins: [],
}

