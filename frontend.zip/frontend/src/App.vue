<template>
  <div class="flex flex-col">
    <Menus />
    <RouterView />
    <FooterView />
  </div>
</template>

<script setup>
import { RouterLink, RouterView } from "vue-router";
import Menus from "./components/Menus.vue";
import FooterView from "@/views/FooterView.vue";
</script>
