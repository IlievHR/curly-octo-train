
<template>
    <main>
      <Upload/>
    </main>
  </template>
  
  <script setup>
  import Upload from '../components/Upload.vue';
  </script>
  