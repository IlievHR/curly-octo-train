
<template>
    <main>
      <Registration/>
    </main>
  </template>
  
  <script setup>
  import Registration from '../components/Login.vue';
  </script>
  