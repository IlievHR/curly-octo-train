<template>
  <main>
    <TheWelcome />
  </main>
</template>

<script setup>
import TheWelcome from "../components/TheWelcome.vue";
</script>
