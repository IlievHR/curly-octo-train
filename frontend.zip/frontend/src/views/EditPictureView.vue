<template>
  <main>
    <EditPicture />
  </main>
</template>

<script setup>
import EditPicture from "@/components/EditPicture.vue";
</script>
