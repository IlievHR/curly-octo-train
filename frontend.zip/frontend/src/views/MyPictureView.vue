
<template>
    <main>
      <MyPictures/>
    </main>
  </template>
  
  
  <script setup>
  import MyPictures from '../components/MyPictures.vue'
  </script>
  