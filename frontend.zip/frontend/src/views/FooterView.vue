<template>
  <main>
    <Footerr />
  </main>
</template>

<script setup>
import Footerr from "@/components/Footerr.vue";
</script>
