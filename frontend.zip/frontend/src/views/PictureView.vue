<template>
  <main>
    <SinglePicture />
  </main>
</template>

<script setup>
import SinglePicture from "../components/SinglePicture.vue";
</script>
