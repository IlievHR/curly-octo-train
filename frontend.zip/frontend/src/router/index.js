import { createRouter, createWebHistory } from 'vue-router'
import HomeView from '../views/HomeView.vue'
import RegisterView from '../views/RegisterView.vue'
import LoginView from '../views/LoginView.vue'
import UploadView from '../views/UploadView.vue'
import MyPictureView from '../views/MyPictureView.vue'
import PictureView from '../views/PictureView.vue'
import EditPictureView from '../views/EditPictureView.vue'

const router = createRouter({
  history: createWebHistory(import.meta.env.BASE_URL),
  routes: [
    {
      path: '/',
      name: 'home',
      component: HomeView
    },
    {
      path: '/register',
      name: 'register',
      component: RegisterView
    },
    {
      path: '/login',
      name: 'login',
      component: LoginView
    },
    {
      path: '/upload',
      name: 'upload',
      component: UploadView
    },
    {
      path: '/private',
      name: 'private',
      component: MyPictureView
    },
    {
      path: '/picture/:id',
      name: 'picture',
      component: PictureView
    },
    {
      path: '/picture/:id/edit',
      name: 'edit',
      component: EditPictureView
    }
   ]
})

export default router
