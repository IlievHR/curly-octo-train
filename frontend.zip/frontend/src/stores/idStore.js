import { ref, computed } from 'vue'
import { defineStore } from 'pinia'

export const useIdStore = defineStore('id', {
  state: () => ({
    sendId: localStorage.getItem('sendId') || null,
  }),
  actions: {
    setSendId(id) {
      this.sendId = id;
      localStorage.setItem('sendId', id);
    },
  },
});