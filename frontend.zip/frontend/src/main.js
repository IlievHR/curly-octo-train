import './assets/main.css'
import { createApp } from 'vue'
import { createPinia } from 'pinia'
import App from './App.vue'
import router from './router'
import VPagination from "@hennge/vue3-pagination"

const app = createApp(App)

app.use(createPinia())
app.use(router)

app.component('vpagination', VPagination)

app.mount('#app')
