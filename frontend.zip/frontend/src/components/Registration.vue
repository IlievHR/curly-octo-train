<template>
  <div class="min-h-screen bg-gray-100 text-center antialiased pt-20">
    <h1 class="text-3xl font-semibold mb-4">Register</h1>
    <form action="#" @submit.prevent="handleRegister">
      <div
        class="overflow-hidden shadow sm:rounded-md max-w-sm mx-auto text-left"
      >
        <div class="bg-white px-4 py-5 sm:p-6">
          <div>
            <input
              type="text"
              name="name"
              id="name"
              v-model="credentials.name"
              placeholder="Username"
              class="mt-1 block w-full px-3 py-2 rounded-md border border-gray-300 shadow-sm focus:border-black focus:outline-none"
            />
            <div v-if="nameError" class="text-red-500">{{ nameError }}</div>
          </div>
          <div class="mt-2">
            <input
              type="email"
              name="email"
              id="email"
              v-model="credentials.email"
              placeholder="Email"
              class="mt-1 block w-full px-3 py-2 rounded-md border border-gray-300 shadow-sm focus:border-black focus:outline-none"
            />
            <div v-if="emailError" class="text-red-500">{{ emailError }}</div>
          </div>
          <div class="mt-2">
            <input
              type="password"
              name="password"
              id="password"
              v-model="credentials.password"
              placeholder="Password"
              class="mt-1 block w-full px-3 py-2 rounded-md border border-gray-300 shadow-sm focus:border-black focus:outline-none"
            />
            <div v-if="passwordError" class="text-red-500">
              {{ passwordError }}
            </div>
          </div>
        </div>

        <div class="bg-gray-50 px-4 py-3 text-right sm:px-6">
          <button
            type="submit"
            @submit.prevent="handleRegister"
            class="inline-flex justify-center rounded-md border border-transparent bg-black py-2 px-4 text-sm font-medium text-white shadow-sm hover:bg-gray-600 focus:outline-none"
          >
            Register
          </button>
        </div>
      </div>
    </form>
  </div>
</template>

<script setup>
import { onMounted, reactive, ref } from "vue";
import axios from "axios";
import { useRouter } from "vue-router";
import { useAuthStore } from "@/authStore";

const store = useAuthStore();
const router = useRouter();
const credentials = reactive({
  name: "",
  email: "",
  password: "",
});
const nameError = ref("");
const emailError = ref("");
const passwordError = ref("");

onMounted(() => {
  if (localStorage.getItem("token")) {
    router.push({
      name: "home",
    });
  }
});

const handleRegister = async () => {
  try {
    const response = await axios.post(
      "http://localhost:8000/api/register",
      credentials
    );
    console.log(response.data.message);
    store.login(response.data.token);

    router.push({
      name: "home",
    });
  } catch (error) {
    if (
      error.response &&
      error.response.status === 422 &&
      error.response.data.errors
    ) {
      const errors = error.response.data.errors;

      if (errors.name) {
        nameError.value = errors.name[0];
      }

      if (errors.email) {
        emailError.value = errors.email[0];
        credentials.email = "";
      }

      if (errors.password) {
        passwordError.value = errors.password[0];
        credentials.password = "";
      }
    } else {
      console.error(error);
      alert(error.response.data.message);
    }
  }
};
</script>
