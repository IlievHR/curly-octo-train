<template>
  <div>
    <div v-if="picture" class="h-auto flex justify-end">
      <div class="w-1/2 h-1/2 flex flex-col items-center pl-5">
        <!-- show picture -->
        <h1 v-if="picture" class="text-3xl font-bold text-end">
          Picture: {{ picture.name }}
        </h1>
        <img :src="picture.url" :alt="picture.name" class="w-auto h-auto" />
        <p class="pb-1">Uploaded by: {{ picture.user.name }}</p>
      </div>

      <!-- handle comments-->
      <div class="w-1/2 h-1/2 flex flex-col items-center pl-2 pt-16">
        <div class="w-11/12">
          <div v-if="picture.comments.length > 0">
            <div
              v-for="comment in picture.comments"
              :key="comment.id"
              class="mb-4 p-3 border rounded overflow-wrap break-words whitespace-normal"
            >
              <p v-if="comment" class="text-center">
                <strong>{{ comment.user_name }}</strong
                >: {{ comment.content }} - {{ formatDate(comment.created_at) }}
              </p>
            </div>
          </div>

          <div v-else>
            <p class="text-center">No comments</p>
          </div>
          <v-pagination
            v-model="page"
            :pages="pageCount"
            :range-size="1"
            active-color="#DCEDFF"
            @update:modelValue="fetchComments"
          />
          <div class="mt-4 pb-4" v-if="store.isAuthenticated">
            <textarea
              v-model="newComment"
              rows="3"
              placeholder="Add a comment..."
              class="w-full px-3 py-2 border rounded focus:outline-none focus:border-blue-500"
              :disabled="submittingComment"
              @keyup.enter="submitComment"
            ></textarea>
            <button
              @click.prevent="submitComment"
              :disabled="submittingComment"
              class="mt-2 px-4 py-2 bg-blue-500 text-white rounded hover:bg-blue-600 disabled:opacity-50"
            >
              Post Comment
            </button>
          </div>
          <p v-else class="text-center">
            You must be authenticated to post a comment.
          </p>
        </div>
      </div>
    </div>
    <p v-else class="text-center">Loading...</p>
  </div>
  <!-- Other stuff-->
  <div v-if="picture">
    <PictureDetails />
  </div>
</template>

<script setup>
import axios from "axios";
import { ref, onMounted, watch } from "vue";
import { useRouter } from "vue-router";
import { useAuthStore } from "@/authStore";
import { useIdStore } from "../stores/idStore";
import PictureDetails from "./PictureDetails.vue";

import VPagination from "@hennge/vue3-pagination";
import "@hennge/vue3-pagination/dist/vue3-pagination.css";

//  properties
const newComment = ref("");
const submittingComment = ref(false);
const picture = ref(null);
const comments = ref([]);

// Fetch the picture
const route = useRouter();
const store = useAuthStore();
const pictureId = useIdStore();

// pagination
const page = ref(1);
const pageCount = ref(null);

async function fetchPicture(id) {
  try {
    const response = await axios.get(`http://localhost:8000/api/picture/${id}`);
    picture.value = response.data.data;
    pageCount.value = response.data.page_count;

    console.log("API Response:", response.data);
  } catch (error) {
    console.error("Failed to fetch picture:", error);
  }
}

async function submitComment() {
  if (!newComment.value.trim()) {
    return;
  }

  submittingComment.value = true;

  try {
    const token = localStorage.getItem("token");

    const response = await axios.post(
      `http://localhost:8000/api/picture/${pictureId.sendId}/comments`,
      { content: newComment.value },
      {
        headers: {
          Authorization: `Bearer ${token}`,
        },
      }
    );

    const newCommentData = response.data;

    picture.value.comments.unshift(newCommentData);

    newComment.value = "";
    submittingComment.value = false;
  } catch (error) {
    console.error("Failed to post comment:", error);
    submittingComment.value = false;
  }
}
const formatDate = (dateTimeString) => {
  const dateTime = new Date(dateTimeString);
  return `${dateTime.toLocaleDateString()} ${dateTime.toLocaleTimeString()}`;
};
onMounted(() => {
  fetchPicture(pictureId.sendId);
});

async function fetchComments(page) {
  try {
    const response = await axios.get(
      `http://localhost:8000/api/picture/${pictureId.sendId}/comments?page=${page}`
    );
    picture.value.comments = response.data.data;
  } catch (error) {
    console.error("Failed to fetch comments:", error);
  }
}

watch(page, (newPage) => {
  fetchComments(newPage);
});
</script>
