<template>
  <div>
    <h1 class="text-3xl font-bold mb-4">Picture Gallery</h1>
    <v-pagination
      v-model="currentPage"
      :pages="totalPages"
      :range-size="1"
      active-color="#007bff"
      @update:modelValue="loadPictures"
    />
    <div class="columns-3">
      <div
        v-for="picture in pictures"
        :key="picture.id"
        @click.prevent="openPictureDetails(picture.id)"
      >
        <img :src="picture.url" :alt="picture.name" />
      </div>
    </div>
  </div>
</template>

<script setup>
import axios from "axios";
import { useRouter } from "vue-router";
import { ref, onMounted } from "vue";
import { useIdStore } from "../stores/idStore";
import VPagination from "@hennge/vue3-pagination";
import "@hennge/vue3-pagination/dist/vue3-pagination.css";

const router = useRouter();
const pictures = ref([]);

const currentPage = ref(1);
const totalPages = ref(1);

const idForPicture = useIdStore();
const openPictureDetails = (id) => {
  idForPicture.setSendId(id);
  router.push(`/picture/${id}`);
};

const loadPictures = async (page) => {
  try {
    const response = await axios.get(
      `http://localhost:8000/api/pictures?page=${page}`
    );
    pictures.value = response.data.data.data;
    currentPage.value = response.data.data.current_page;
    totalPages.value = response.data.data.last_page;
    console.log("API Response:", response.data.data);
  } catch (error) {
    console.error("Failed to fetch pictures:", error);
  }
};
onMounted(() => {
  loadPictures(currentPage.value);
});
</script>

<style>
img {
  width: 100%;
  height: auto;
  margin: 4% auto;
  box-shadow: -3px 5px 15px #000;
  cursor: pointer;
}
</style>
