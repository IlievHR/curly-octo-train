<template>
  <div>
    <h1 class="text-3xl font-bold mb-4">Your Pictures</h1>

    <div class="grid grid-cols-4 gap-4">
      <div
        class="container flex flex-col items-center justify-center"
        v-for="picture in userPictures"
        :key="picture.id"
      >
        <img :src="picture.url" :alt="picture.name" class="w-full h-auto" />
        <div class="space-x-4">
          <button
            @click.prevent="deletePicture(picture.id)"
            class="mt-2 px-4 py-2 bg-gray-400 text-white rounded hover:bg-red-600"
          >
            Delete
          </button>
          <button
            @click.prevent="openEditPicture(picture.id)"
            class="mt-2 px-4 py-2 bg-gray-400 text-white rounded hover:bg-blue-600"
          >
            Edit
          </button>
        </div>
      </div>
    </div>
  </div>
</template>

<script setup>
import axios from "axios";
import { ref, onMounted, computed } from "vue";
import { useRouter } from "vue-router";
import { useAuthStore } from "@/authStore";
import { useIdStore } from "../stores/idStore";

const store = useAuthStore();
const userPictures = ref([]);
const router = useRouter();

const idForPicture = useIdStore();
const openEditPicture = (id) => {
  idForPicture.setSendId(id);
  router.push(`/picture/${id}/edit`);
};

const deletePicture = async (pictureId) => {
  try {
    const token = localStorage.getItem("token");
    const response = await axios.delete(
      `http://localhost:8000/api/pictures/${pictureId}`,
      {
        headers: {
          Authorization: `Bearer ${token}`,
        },
      }
    );

    if (response.status === 200) {
      userPictures.value = userPictures.value.filter(
        (picture) => picture.id !== pictureId
      );
      console.log(response.data.message);
    } else {
      console.error("Picture deletion failed:", response.data.message);
      alert(response.data.message);
    }
  } catch (error) {
    console.error("Picture deletion failed:", error);
    alert(error.response.data.message);
  }
};

onMounted(() => {
  if (!store.isAuthenticated) {
    router.push("/login");
  }
});

onMounted(async () => {
  try {
    if (store.isAuthenticated) {
      const token = localStorage.getItem("token");
      const response = await axios.get(
        "http://localhost:8000/api/pictures/private",
        {
          headers: {
            Authorization: `Bearer ${token}`,
          },
        }
      );

      userPictures.value = response.data.pictures;
    }
  } catch (error) {
    console.error("Failed to fetch user pictures:", error);
  }
});
</script>
