<template>
  <div class="border-t-2 border-black mt-5">
    <h1>The id is {{ pictureInfo.id }}</h1>
    <p>Description: {{ pictureInfo.description }}</p>
    <div>
      <h2>Tags:</h2>
      <div class="flex flex-wrap gap-2">
        <span
          v-for="tag in pictureInfo.tags"
          :key="tag.id"
          class="bg-gray-200 px-2 py-1 rounded-lg text-sm"
        >
          {{ tag.name }}
        </span>
      </div>
    </div>
  </div>
</template>

<script setup>
import { ref, onMounted } from "vue";
import axios from "axios";
import { useIdStore } from "../stores/idStore";

const pictureId = useIdStore();
const pictureInfo = ref("");
const tags = ref([]);

onMounted(async () => {
  try {
    const response = await axios.get(
      `http://localhost:8000/api/picture/${pictureId.sendId}`
    );
    pictureInfo.value = response.data.data;
    console.log("Picture details and tags:", response.data);
  } catch (error) {
    console.error("Failed to fetch picture details and tags:", error);
  }
});
</script>
