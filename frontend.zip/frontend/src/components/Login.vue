<template>
  <div class="min-h-screen bg-gray-100 text-center antialiased pt-20">
    <h1 class="text-3xl font-semibold mb-4">Login</h1>
    <form action="#" @submit.prevent="handleLogin">
      <div
        class="overflow-hidden shadow sm:rounded-md max-w-sm mx-auto text-left"
      >
        <div class="bg-white px-4 py-5 sm:p-6">
          <div v-if="errorMessages.length > 0" class="text-red-500">
            <ul>
              <li v-for="error in errorMessages" :key="error">{{ error }}</li>
            </ul>
          </div>
          <div class="mt-2">
            <input
              type="email"
              v-model="credentials.email"
              name="email"
              id="email"
              placeholder="Enter Email"
              class="mt-1 block w-full px-3 py-2 rounded-md border border-gray-300 shadow-sm focus:border-black focus:outline-none"
            />
          </div>
          <div class="mt-2">
            <input
              type="password"
              v-model="credentials.password"
              name="password"
              id="password"
              placeholder="Enter Password"
              class="mt-1 block w-full px-3 py-2 rounded-md border border-gray-300 shadow-sm focus:border-black focus:outline-none"
            />
          </div>
        </div>

        <div
          class="bg-gray-50 px-4 py-3 text-right sm:px-6 flex justify-between"
        >
          <router-link
            to="/register"
            class="inline-flex justify-center rounded-md border border-transparent bg-black py-2 px-4 text-sm font-medium text-white shadow-sm hover:bg-gray-600 focus:outline-none"
            >Register</router-link
          >

          <button
            type="submit"
            @submit.prevent="handleLogin"
            class="inline-flex justify-center rounded-md border border-transparent bg-black py-2 px-4 text-sm font-medium text-white shadow-sm hover:bg-gray-600 focus:outline-none"
          >
            Login
          </button>
        </div>
      </div>
    </form>
  </div>
</template>

<script setup>
import { onMounted, reactive, ref } from "vue";
import axios from "axios";
import { useRouter } from "vue-router";
import { useAuthStore } from "@/authStore";

const store = useAuthStore();
const router = useRouter();
const errorMessages = ref([]);
const credentials = reactive({
  email: "",
  password: "",
});

onMounted(() => {
  if (localStorage.getItem("token")) {
    router.push({
      name: "home",
    });
  }
});

const handleLogin = async () => {
  try {
    const response = await axios.post(
      `http://localhost:8000/api/login`,
      credentials
    );

    store.login(response.data.token);

    router.push({
      name: "home",
    });

    console.log("Login successfully:", response.data.message);
  } catch (error) {
    if (
      error.response &&
      error.response.status === 422 &&
      error.response.data.errors
    ) {
      const errors = error.response.data.errors;
      errorMessages.value = Object.values(errors).flat();
    } else {
      errorMessages.value = [
        error.response.data.message || "An error occurred.",
      ];
    }
    console.error(error);

    credentials.password = "";
  }
};
</script>
