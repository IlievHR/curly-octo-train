<template>
  <div>
    <div
      v-if="showFooter"
      class="fixed bottom-0 right-0 bg-red-500 p-2 rounded-full m-4"
    >
      <button
        @click="scrollToTop"
        class="w-6 h-6 flex justify-center items-center rounded-full"
      >
        <h1 class="text-2xl font-bold text-white">GO</h1>
      </button>
    </div>
  </div>
</template>

<script setup>
import { ref, onMounted, onUnmounted } from "vue";

const showFooter = ref(false);

const scrollToTop = () => {
  window.scrollTo({ top: 0, behavior: "smooth" });
};

const handleScroll = () => {
  const windowHeight = window.innerHeight;
  const scrollY = window.scrollY;
  const scrollThreshold = 100;

  showFooter.value =
    scrollY > scrollThreshold &&
    scrollY + windowHeight < document.body.scrollHeight;
};

onMounted(() => {
  window.addEventListener("scroll", handleScroll);
});

onUnmounted(() => {
  window.removeEventListener("scroll", handleScroll);
});
</script>
