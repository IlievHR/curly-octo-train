<template>
  <div
    class="min-h-screen bg-gradient-to-r from-teal-400 via-indigo-500 to-purple-600 text-center antialiased pt-20"
  >
    <h1 class="text-3xl font-semibold mb-4">Upload Picture</h1>
    <form action="#" @submit.prevent="handleSavePicture">
      <div
        class="overflow-hidden shadow sm:rounded-md max-w-sm mx-auto text-left"
      >
        <div
          class="bg-gradient-to-r from-teal-400 via-indigo-500 to-purple-600 px-4 py-5 sm:p-6"
        >
          <div v-if="errorMessages.length > 0" class="text-red-500">
            <ul>
              <li v-for="error in errorMessages" :key="error">{{ error }}</li>
            </ul>
          </div>
          <div>
            <input
              type="text"
              name="url"
              id="url"
              v-model="pictureDetails.url"
              placeholder="URL"
              class="mt-1 block w-full px-3 py-2 rounded-md border border-gray-300 shadow-sm focus:border-black focus:outline-none"
            />
          </div>
          <div class="mt-2">
            <input
              type="text"
              name="name"
              id="name"
              v-model="pictureDetails.name"
              placeholder="author"
              class="mt-1 block w-full px-3 py-2 rounded-md border border-gray-300 shadow-sm focus:border-black focus:outline-none"
            />
          </div>
          <div>
            <textarea
              id="description"
              name="description"
              v-model="pictureDetails.description"
              placeholder="Description"
              class="mt-1 block w-full px-3 py-2 rounded-md border border-gray-300 shadow-sm focus:border-black focus:outline-none"
            ></textarea>
          </div>
          <div class="mt-2">
            <input
              type="text"
              name="tags"
              id="tags"
              v-model="pictureDetails.tags"
              placeholder="Tags (space-separated)"
              class="mt-1 block w-full px-3 py-2 rounded-md border border-gray-300 shadow-sm focus:border-black focus:outline-none"
            />
          </div>
          <div class="mt-2">
            <h2>Make private</h2>
            <Switch
              v-model="pictureDetails.is_private"
              :class="pictureDetails.is_private ? 'bg-teal-400' : 'bg-gray-200'"
              class="relative inline-flex h-6 w-11 items-center rounded-full"
            >
              <span
                :class="
                  pictureDetails.is_private ? 'translate-x-6' : 'translate-x-1'
                "
                class="inline-block h-4 w-4 transform rounded-full bg-white transition"
              />
            </Switch>
          </div>
        </div>
        <div
          class="bg-gradient-to-r from-teal-400 via-indigo-500 to-purple-600 px-4 py-3 text-right sm:px-6"
        >
          <button
            type="submit"
            @click.prevent="handleSavePicture"
            :disabled="submitting"
            class="inline-flex justify-center rounded-md border border-transparent purple-600 py-2 px-4 text-sm font-medium text-white shadow-sm hover:bg-indigo-500 focus:outline-none"
          >
            Continue
          </button>
          <TransitionRoot appear :show="isOpen" as="template">
            <Dialog as="div" @close="closeModal" class="relative z-10">
              <TransitionChild
                as="template"
                enter="duration-300 ease-out"
                enter-from="opacity-0"
                enter-to="opacity-100"
                leave="duration-200 ease-in"
                leave-from="opacity-100"
                leave-to="opacity-0"
              >
                <div class="fixed inset-0 bg-black bg-opacity-25" />
              </TransitionChild>

              <div class="fixed inset-0 overflow-y-auto">
                <div
                  class="flex min-h-full items-center justify-center p-4 text-center"
                >
                  <TransitionChild
                    as="template"
                    enter="duration-300 ease-out"
                    enter-from="opacity-0 scale-95"
                    enter-to="opacity-100 scale-100"
                    leave="duration-200 ease-in"
                    leave-from="opacity-100 scale-100"
                    leave-to="opacity-0 scale-95"
                  >
                    <DialogPanel
                      class="w-full max-w-md transform overflow-hidden rounded-2xl bg-white p-6 text-left align-middle shadow-xl transition-all"
                    >
                      <DialogTitle
                        as="h3"
                        class="text-lg font-medium leading-6 text-gray-900"
                      >
                        {{ successfullyUploaded }}
                      </DialogTitle>
                      <div class="mt-2">
                        <p class="text-sm text-gray-500">
                          {{ successfullyUploaded }}
                        </p>
                      </div>

                      <div class="mt-4">
                        <button
                          type="button"
                          class="inline-flex justify-center rounded-md border border-transparent bg-blue-100 px-4 py-2 text-sm font-medium text-blue-900 hover:bg-blue-200 focus:outline-none focus-visible:ring-2 focus-visible:ring-blue-500 focus-visible:ring-offset-2"
                          @click="closeModal"
                        >
                          Got it, thanks!
                        </button>
                      </div>
                    </DialogPanel>
                  </TransitionChild>
                </div>
              </div>
            </Dialog>
          </TransitionRoot>
        </div>
      </div>
    </form>
  </div>
</template>

<script setup>
import { reactive, ref } from "vue";
import axios from "axios";
import { useAuthStore } from "@/authStore";
import { useRouter } from "vue-router";
import { onMounted } from "vue";
import {
  TransitionRoot,
  TransitionChild,
  Dialog,
  DialogPanel,
  DialogTitle,
  Switch,
} from "@headlessui/vue";

const isOpen = ref(false);
const router = useRouter();
const store = useAuthStore();
const submitting = ref(false);
const pictureDetails = reactive({
  url: "",
  name: "",
  is_private: false,
  description: "",
  tags: "",
});

onMounted(() => {
  if (!store.isAuthenticated) {
    router.push("/login");
  }
});

const successfullyUploaded = ref("");
const errorMessages = ref([]);

const handleSavePicture = async () => {
  try {
    errorMessages.value = [];
    submitting.value = true;

    const token = localStorage.getItem("token");
    const response = await axios.post(
      "http://localhost:8000/api/picture",
      { ...pictureDetails },

      {
        headers: {
          Authorization: `Bearer ${token}`,
        },
      }
    );
    console.log("details", pictureDetails);
    console.log("Picture uploaded successfully:", response.data);

    successfullyUploaded.value = response.data.success;
    isOpen.value = true;

    pictureDetails.url = "";
    pictureDetails.name = "";
    pictureDetails.is_private = false;
    pictureDetails.tagsInput = "";
    pictureDetails.description = "";
  } catch (error) {
    if (
      error.response &&
      error.response.status === 422 &&
      error.response.data.errors
    ) {
      const errors = error.response.data.errors;
      errorMessages.value = Object.values(errors).flat();
    } else {
      errorMessages.value = [
        error.response.data.message || "An error occurred.",
      ];
    }
    console.error(error);
  } finally {
    submitting.value = false;
  }
};

function closeModal() {
  isOpen.value = false;
}
</script>
