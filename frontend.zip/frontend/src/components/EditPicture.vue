<template>
  <div
    class="min-h-screen bg-gray-100 text-center antialiased pt-20 flex justify-evenly"
  >
    <div class="w-1/2 h-1/2 flex flex-col items-center pl-5">
      <!-- show picture -->
      <img
        :src="currentPicture.url"
        :alt="currentPicture.name"
        class="w-auto h-auto"
      />
    </div>
    <form action="#" @submit.prevent="handleSavePicture">
      <h1 class="text-3xl font-semibold mb-4">Edit Picture</h1>

      <div
        class="overflow-hidden shadow sm:rounded-md max-w-sm mx-auto text-left"
      >
        <div class="bg-white px-4 py-5 sm:p-6">
          <div v-if="successfullyUploaded" class="text-green-500">
            {{ successfullyUploaded }}
          </div>
          <div v-if="errorMessages.length > 0" class="text-red-500">
            <ul>
              <li v-for="error in errorMessages" :key="error">{{ error }}</li>
            </ul>
          </div>
          <div>
            <input
              type="text"
              name="url"
              id="url"
              v-model="pictureDetails.url"
              placeholder="new URL"
              class="mt-1 block w-full px-3 py-2 rounded-md border border-gray-300 shadow-sm focus:border-black focus:outline-none"
            />
          </div>
          <div class="mt-2">
            <input
              type="text"
              name="name"
              id="name"
              v-model="pictureDetails.name"
              :placeholder="currentPicture.name"
              class="mt-1 block w-full px-3 py-2 rounded-md border border-gray-300 shadow-sm focus:border-black focus:outline-none"
            />
          </div>
        </div>
        <div class="bg-gray-50 px-4 py-3 text-right sm:px-6">
          <button
            type="submit"
            @click.prevent="handleSavePicture"
            :disabled="submitting || isSubmitDisabled"
            class="inline-flex justify-center rounded-md border border-transparent bg-black py-2 px-4 text-sm font-medium text-white shadow-sm hover:bg-gray-600 focus:outline-none"
          >
            <span v-if="!submitting">Continue</span>
            <span v-else>Submitting...</span>
          </button>
        </div>
      </div>
    </form>
  </div>
</template>

<script setup>
import { reactive, ref, computed } from "vue";
import axios from "axios";
import { useAuthStore } from "@/authStore";
import { useRouter } from "vue-router";
import { onMounted } from "vue";
import { useIdStore } from "../stores/idStore";

const pictureId = useIdStore();
const router = useRouter();
const store = useAuthStore();
const currentPicture = ref("");
const pictureDetails = reactive({
  url: "",
  name: "",
});
onMounted(async () => {
  if (!store.isAuthenticated) {
    router.push("/login");
  }

  try {
    const response = await axios.get(
      `http://localhost:8000/api/picture/${pictureId.sendId}`
    );
    console.log("API Response:", response.data);

    currentPicture.value = response.data.data;
  } catch (error) {
    console.error(error);
  }
});

const successfullyUploaded = ref("");
const errorMessages = ref([]);
const submitting = ref(false);

const handleSavePicture = async () => {
  try {
    errorMessages.value = [];
    submitting.value = true;

    const token = localStorage.getItem("token");
    const response = await axios.put(
      `http://localhost:8000/api/picture/${pictureId.sendId}/edit`,
      { ...pictureDetails },
      {
        headers: {
          Authorization: `Bearer ${token}`,
        },
      }
    );

    console.log("Picture uploaded successfully:", response.data);

    successfullyUploaded.value = response.data.message;

    setTimeout(() => {
      successfullyUploaded.value = "";
    }, 3000);

    pictureDetails.url = "";
    pictureDetails.name = "";
  } catch (error) {
    if (
      error.response &&
      error.response.status === 422 &&
      error.response.data.errors
    ) {
      const errors = error.response.data.errors;
      errorMessages.value = Object.values(errors).flat();
    } else {
      errorMessages.value = [
        error.response.data.message || "An error occurred.",
      ];
    }
    console.error(error);
  } finally {
    submitting.value = false;
  }
};

const isSubmitDisabled = computed(() => {
  return !pictureDetails.url.trim() && !pictureDetails.name.trim();
});
</script>
